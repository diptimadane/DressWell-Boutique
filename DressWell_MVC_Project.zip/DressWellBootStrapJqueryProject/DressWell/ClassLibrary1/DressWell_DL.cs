﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DressWell_BusinessModel;
using DressWell_BusinessLayer;
using System.Data;

namespace DressWell_DataLayer
{
    public class DressWell_DL
    {
        public static DressWell_BusinessModel.DressWell_BM getLoginInformation()
        {
            //Code will be added later
            return null;
        }

    }
}
