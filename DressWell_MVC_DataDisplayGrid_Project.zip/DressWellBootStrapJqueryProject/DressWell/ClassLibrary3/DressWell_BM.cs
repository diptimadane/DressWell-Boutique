﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace DressWell_BusinessModel
{
   public class DressWell_BM
    {        
        [DisplayName("Name")]
        public string Name { get; set; }

        [DisplayName("Address")]
        public string Address { get; set; }

        [DisplayName("Gender")]
        public string Gender { get; set; }

        [DisplayName("PrevOrder")]
        public string PrevOrder { get; set; }

        [DisplayName("Style")]
        public string Style { get; set; }

        [DisplayName("PrefTimeOfDelivery")]
        public string PrefTimeOfDelivery { get; set; }
    }
}
