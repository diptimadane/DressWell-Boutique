﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DressWell_BusinessModel;
using System.Data;
using DressWell_DataLayer;

namespace DressWell_BusinessLayer
{
    public class DressWell_BL
    {
      public static List<DressWell_BM> getCustomerInfo()
        {
         //   DressWell_BM custModel = new DressWell_BM();
            var customerList = new List<DressWell_BM>();
            DataSet dsCustomerSet = new DataSet();

            dsCustomerSet = DressWell_DL.getCustomerInformation();
            if(dsCustomerSet.Tables.Count > 0)
            {
                customerList = dsCustomerSet.Tables[0].AsEnumerable().Select(i => new DressWell_BM()
                {
                    Address=Convert.ToString(i["Address"]),
                    Gender = Convert.ToString(i["Gender"]),
                    Name = Convert.ToString(i["Name"]),
                    PrefTimeOfDelivery = Convert.ToString(i["PrefTimeOfDelivery"]),
                    PrevOrder = Convert.ToString(i["PrevOrder"]),
                    Style = Convert.ToString(i["Style"])
                }).ToList();
            }
         return customerList;
        }
    }
}
