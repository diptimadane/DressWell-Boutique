﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DressWell_DataLayer
{
    public class DressWell_DL
    {
        public static DataSet getCustomerInformation()
        {
            DataSet dsCustomer = new DataSet();
            dsCustomer.DataSetName = "Customer";

            DataTable dt = new DataTable("CustomerInfo");
            dt.Clear();
            dt.Columns.Add(new DataColumn("Address", typeof(string)));
            dt.Columns.Add(new DataColumn("Gender", typeof(string)));
            dt.Columns.Add(new DataColumn("Name", typeof(string)));
            dt.Columns.Add(new DataColumn("PrefTimeOfDelivery", typeof(string)));
            dt.Columns.Add(new DataColumn("PrevOrder", typeof(string)));
            dt.Columns.Add(new DataColumn("Style", typeof(string)));

            DataRow dr = dt.NewRow();
            dr["Address"] = "1234, DressWell Lane, Erie, PA 10000";
            dr["Gender"] = "Female";
            dr["Name"] = "Prachi Arora";
            dr["PrefTimeOfDelivery"] = "Evening";
            dr["PrevOrder"] = "March 10, 2016";
            dr["Style"] = "Petite";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["Address"] = "1231, Inter West Ave, Texas";
            dr["Gender"] = "Female";
            dr["Name"] = "Cathy Cyndi";
            dr["PrefTimeOfDelivery"] = "Morning";
            dr["PrevOrder"] = "Jan 4 2015";
            dr["Style"] = "Formals";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["Address"] = "2123, Best West Bvld, Harrisburg, PA";
            dr["Gender"] = "Male";
            dr["Name"] = "Arjun Phadnis";
            dr["PrefTimeOfDelivery"] = "Afternoon";
            dr["PrevOrder"] = "Aug 22 2014";
            dr["Style"] = "Formals";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["Address"] = "7644, East Face Lane, California";
            dr["Gender"] = "Female";
            dr["Name"] = "Smita Irani";
            dr["PrefTimeOfDelivery"] = "Morning";
            dr["PrevOrder"] = "Jan 9 2013";
            dr["Style"] = "Traditional";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["Address"] = "1111, Test West Nagar, India";
            dr["Gender"] = "Female";
            dr["Name"] = "Rajashree Metha";
            dr["PrefTimeOfDelivery"] = "Afternoon";
            dr["PrevOrder"] = "Oct 10 2012";
            dr["Style"] = "Trendy";
            dt.Rows.Add(dr);
            dsCustomer.Tables.Add(dt);
            return dsCustomer;
        }

    }
}
