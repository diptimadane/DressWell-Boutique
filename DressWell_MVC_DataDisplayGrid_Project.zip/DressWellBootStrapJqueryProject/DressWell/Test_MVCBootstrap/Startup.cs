﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(DressWell.Startup))]
namespace DressWell
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
